import { spawn } from 'node:child_process'
import { once } from 'node:events'

const child = spawn(process.execPath, ['host.mjs'], { cwd: import.meta.dirname, stdio: ['ignore', 'pipe', 'inherit'] })
const t0 = Date.now()
let buf = ''
let port = 0
child.stdout.on('data', (chunk) => {
  buf += chunk.toString()
  const m = buf.match(/HOST_READY (\d+) (\d+)/)
  if (m) { port = Number(m[1]) }
})
while (!port) {
  if (Date.now() - t0 > 10000) throw new Error('no HOST_READY\n' + buf)
  await new Promise(r => setTimeout(r, 20))
}
const helloAt = Date.now() - t0
const ws = new WebSocket(`ws://127.0.0.1:${port}/`)
await once(ws, 'open')
const hello = await new Promise((resolve) => ws.addEventListener('message', e => resolve(JSON.parse(e.data)), { once: true }))
const sentAt = Date.now()
ws.send(JSON.stringify({ op: 'tool.invoke', id: 'p0-1', name: 'todo_write', args: { todos: [{ content: 'p0 bridge probe', status: 'in_progress' }] } }))
const result = await new Promise((resolve) => ws.addEventListener('message', e => resolve(JSON.parse(e.data)), { once: true }))
console.log(JSON.stringify({ spawnToHelloMs: helloAt, helloToToolMs: Date.now() - sentAt, hello, result }, null, 2))
ws.send(JSON.stringify({ op: 'host.stop' }))
await once(child, 'exit')