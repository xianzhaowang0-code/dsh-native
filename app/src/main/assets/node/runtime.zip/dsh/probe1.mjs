import { Context } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import Projections from '@deepseek-ai/dsh-session-projection'
import * as todo from '@deepseek-ai/dsh-tool-todo'

const t0 = Date.now()
const ctx = new Context()
await ctx.plugin(SystemPrompt)
await ctx.plugin(ToolRuntime)
await ctx.plugin(Projections)
console.log('services', !!ctx.systemPrompt, !!ctx.tools, !!ctx.sessionProjections, Date.now() - t0)
await ctx.plugin(todo, { allowParallelInProgress: false })
console.log('plugins loaded', Date.now() - t0)
const names = ctx.tools.names ? ctx.tools.names() : null
console.log('names', JSON.stringify(names))
const tool = ctx.tools.get('todo_write')
console.log('tool', !!tool, typeof tool?.execute)
const events = []
const value = await tool.execute({ todos: [{ content: 'p0 probe', status: 'in_progress' }] }, { agent: { session: { append(t, d) { events.push([t, d]) } } } })
console.log('value', JSON.stringify(value))
console.log('events', JSON.stringify(events))
await ctx.fiber.dispose()